export const dynamic = 'force-dynamic';

export default function LoginLayout({ children }) {
  return children;
}