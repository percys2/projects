"use client";

export default function DeliveryPage() {
  return (
    <div>
      <h1 className="text-xl font-semibold">Módulo de Reparto</h1>
      <p className="text-slate-500">Pronto disponible…</p>
    </div>
  );
}
