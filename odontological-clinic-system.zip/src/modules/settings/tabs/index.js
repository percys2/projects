export { default as GeneralTab } from "./GeneralTab";
export { default as CompanyTab } from "./CompanyTab";
export { default as BranchesTab } from "./BranchesTab";
export { default as UsersTab } from "./UsersTab";
export { default as PermissionsTab } from "./PermissionsTab";
export { default as InvoicingTab } from "./InvoicingTab";