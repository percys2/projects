export const PIPELINE_STAGES = [
  "Nuevo Lead",
  "En Contacto",
  "Interesado",
  "Propuesta Enviada",
  "Negociación",
  "Venta Cerrada",
  "Venta Perdida",
];
