export const paymentMethods = [
  { id: "efectivo", label: "Efectivo" },
  { id: "tarjeta", label: "Tarjeta" },
  { id: "transfer", label: "Transferencia" },
  { id: "credito", label: "Crédito" },
];
