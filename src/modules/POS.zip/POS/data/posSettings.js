export default {
  managerPin: "202120",
  allowDiscounts: true,
};
