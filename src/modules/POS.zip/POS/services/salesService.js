import { generateInvoiceNumber } from "../utils/generateInvoiceNumber";

export const salesService = {
  async makeSale({ orgSlug, branchId, client, cart, paymentType, notes }) {
    console.log("[salesService] makeSale called with:", { orgSlug, branchId, clientId: client?.id, cartLength: cart?.length, paymentType });
    
    let orgId = localStorage.getItem("activeOrgId");
    
    if (!orgId && orgSlug) {
      console.log("[salesService] Fetching orgId from API");
      const orgRes = await fetch("/api/org", {
        headers: { "x-org-slug": orgSlug },
      });
      if (orgRes.ok) {
        const orgData = await orgRes.json();
        orgId = orgData.org_id;
        localStorage.setItem("activeOrgId", orgId);
        console.log("[salesService] Got orgId:", orgId);
      }
    }
    
    if (!orgId) {
      console.error("[salesService] Missing orgId");
      throw new Error("Missing orgId - please select an organization.");
    }
    if (!cart || cart.length === 0) {
      console.error("[salesService] Empty cart");
      throw new Error("El carrito está vacío.");
    }
    if (!branchId) {
      console.error("[salesService] Missing branchId");
      throw new Error("Seleccione una sucursal.");
    }

    const invoice = generateInvoiceNumber();
    const total = cart.reduce((sum, p) => sum + p.qty * p.price, 0);

    const itemsPayload = cart.map((p) => ({
      product_id: p.id || p.product_id || p.productId,
      quantity: p.qty,
      price: Number(p.price),
      cost: Number(p.cost ?? 0),
    }));

    const payload = {
      payment_method: paymentType || "cash",
      notes: notes || null,
      total,
      items: itemsPayload,
    };
    
    if (client?.id) {
      payload.client_id = client.id;
    }

    console.log("[salesService] Making API call with:", { orgId, branchId, client_id: payload.client_id, total, itemsCount: itemsPayload.length });

    const res = await fetch("/api/sales/create-with-items", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-org-id": orgId,
        "x-branch-id": branchId,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    console.log("[salesService] API response:", { ok: res.ok, data });

    if (!res.ok) {
      throw new Error(data.error || "Error creando venta.");
    }

    return {
      ...data.sale,
      invoice: invoice,
      invoice_number: invoice,
      items: cart,
      total,
    };
  },
};
